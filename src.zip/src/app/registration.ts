export class Registration {
    iduser: number=0;
    username: string;
    password: string;
}
