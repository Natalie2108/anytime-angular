import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { Login } from '../login';
import { Registration } from '../registration';

@Component({
  selector: 'app-grouppage',
  templateUrl: './grouppage.component.html',
  styleUrls: ['./grouppage.component.css']
})
export class GrouppageComponent implements OnInit {

  logins: Login[];
  registrations: Registration[];

  constructor(public userService: UserService, private router: Router) { }


  ngOnInit(): void {
    this.reloadAll();
  }

  reloadAll() {
    this.userService.findAll().subscribe(
      rgs => {
        this.registrations = rgs;
      },
      err => {
        console.log(err);
      }
    );
  }


  delete(iduser) {
    this.userService.delete(iduser).subscribe(
      () => this.reloadAll()
    );
  }

  deleteregistration(iduser) {
    this.userService.delete(iduser).subscribe(
      () => this.reloadAll()
    );
    sessionStorage.clear();
    this.router.navigate([''])
  }

  currentUsername = sessionStorage.getItem('username')
  currentID = sessionStorage.getItem('iduser')

  logout() {
    sessionStorage.clear();
    this.router.navigate([''])
  }



}
