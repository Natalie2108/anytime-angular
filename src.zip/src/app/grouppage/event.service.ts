import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Event } from './event';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  constructor(public http: HttpClient) { }

  findAllevents(): Observable<Event[]>  {
    return this.http.get<any>('http://localhost:8080/event')
  }

  saveevents(event: Event) {
    return this.http.post("http://localhost:8080/event", event)
  }

  deleteevents(id) {
    return this.http.delete('http://localhost:8080/event/' + id)
  }

}