import { Component, OnInit } from '@angular/core';
import { AlleventService } from '../allevent.service';
import { Allevent } from '../allevent';
import { Router } from '@angular/router';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css']
})
export class CalendarComponent implements OnInit {

  allevents: Allevent[];

  constructor(private alleventService: AlleventService, private router: Router) {
  }

  ngOnInit(): void {
    this.reloadAllallevents();
  }

  reloadAllallevents() {
    this.alleventService.findAllallevents().subscribe(
      events => {
        this.allevents = events;
      }
    );
  }

  deleteallevents(idevent) {
    this.alleventService.deleteallevents(idevent).subscribe(
      () => this.reloadAllallevents()
    );
  }

  logout() {
    sessionStorage.clear();
    this.router.navigate([''])
  }

}
