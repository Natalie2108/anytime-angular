export class Event {
    id: number=0;
    username: string;
    remark: string;
}
