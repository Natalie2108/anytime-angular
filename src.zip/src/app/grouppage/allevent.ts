export class Allevent {
    idevent: number = 0;
    eventname: string;
    eventlocation: string;
    eventdescription: string;
    eventdate: Date;
    eventdateformatted: string;
}