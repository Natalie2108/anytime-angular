import { Component, OnInit, Input } from '@angular/core';
import { CalendarComponent } from '../calendar/calendar.component';
import { Allevent } from '../allevent';
import { AlleventService } from '../allevent.service';
import { Event } from '../event';
import { EventService } from '../event.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {

  event = new Event()
  allevents: Allevent[];
  events: Event[];
  allevent = new Allevent()


  constructor(private eventService: EventService, private alleventService: AlleventService, private router: Router) { }

  ngOnInit(): void {
    this.reloadAllallevents();
    this.reloadAllevents();
  }

  public saveallevents() {
    this.alleventService.saveallevents(this.allevent).subscribe(
      () => this.reloadAllallevents()
    )
  }

  public saveevents() {
    this.eventService.saveevents(this.event).subscribe(
      () => this.reloadAllevents());
  }


  reloadAllallevents() {
    this.alleventService.findAllallevents().subscribe(
      allevents => {
        this.allevents = allevents;
      }
    );
  }

  deleteallevents(idevent) {
    this.alleventService.deleteallevents(idevent).subscribe(
      () => this.reloadAllallevents()
    );
  }

  reloadAllevents() {
    this.eventService.findAllevents().subscribe(
      events => {
        this.events = events;
      },
      err => {
        console.log(err);
      }
    );
  }

  deleteevents(id) {
    this.eventService.deleteevents(id).subscribe(
      () => this.reloadAllevents()
    );
  }

  currentUsername = sessionStorage.getItem('username')

  logout() {
    sessionStorage.clear();
    this.router.navigate([''])
  }

}
