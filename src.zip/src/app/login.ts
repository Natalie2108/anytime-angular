export class Login {
    iduser: number=0;
    username: string;
    password: string;
}
